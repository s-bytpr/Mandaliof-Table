﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;

namespace anasor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_TextChanged(object sender, EventArgs e)
        {
            String strPath = "Images\\" + label1.Text + ".png";
            Image image;
            image = Image.FromFile(Path.Combine(Path.GetDirectoryName(Directory.GetCurrentDirectory()),
             strPath));
            pictureBox1.Image = image; 
        }
        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = button2.Text;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = button1.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            label1.Text = button8.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label1.Text = button11.Text;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            label1.Text = button14.Text;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            label1.Text = button16.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = button3.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            label1.Text = button9.Text;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            label1.Text = button12.Text;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            label1.Text = button15.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = button4.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label1.Text = button10.Text;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            label1.Text = button13.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Text = button5.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label1.Text = button7.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label1.Text = button6.Text;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            label1.Text = button18.Text;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            label1.Text = button19.Text;
        }

        private void button25_Click(object sender, EventArgs e)
        {
            label1.Text = button25.Text;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            label1.Text = button20.Text;
        }

        private void button23_Click(object sender, EventArgs e)
        {
            label1.Text = button23.Text;
        }

        private void button26_Click(object sender, EventArgs e)
        {
            label1.Text = button26.Text;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            label1.Text = button21.Text;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            label1.Text = button24.Text;
        }

        private void button28_Click(object sender, EventArgs e)
        {
            label1.Text = button28.Text;
        }

        private void button27_Click(object sender, EventArgs e)
        {
            label1.Text = button27.Text;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            label1.Text = button22.Text;
        }

        private void button30_Click(object sender, EventArgs e)
        {
            label1.Text = button30.Text;
        }

        private void button31_Click(object sender, EventArgs e)
        {
            label1.Text = button31.Text;
        }

        private void button29_Click(object sender, EventArgs e)
        {
            label1.Text = button29.Text;
        }

        private void button32_Click(object sender, EventArgs e)
        {
            label1.Text = button32.Text;
        }

        private void button34_Click(object sender, EventArgs e)
        {
            label1.Text = button34.Text;
        }

        private void button33_Click(object sender, EventArgs e)
        {
            label1.Text = button33.Text;
        }

        private void button35_Click(object sender, EventArgs e)
        {
            label1.Text = button35.Text;
        }

        private void button36_Click(object sender, EventArgs e)
        {
            label1.Text = button36.Text;
        }

        private void button37_Click(object sender, EventArgs e)
        {
            label1.Text = button37.Text;
        }

        private void button38_Click(object sender, EventArgs e)
        {
            label1.Text = button38.Text;
        }

        private void button39_Click(object sender, EventArgs e)
        {
            label1.Text = button39.Text;
        }

        private void button40_Click(object sender, EventArgs e)
        {
            label1.Text = button40.Text;
        }

        private void button41_Click(object sender, EventArgs e)
        {
            label1.Text = button41.Text;
        }

        private void button42_Click(object sender, EventArgs e)
        {
            label1.Text = button42.Text;
        }

        private void button43_Click(object sender, EventArgs e)
        {
            label1.Text = button43.Text;
        }

        private void button44_Click(object sender, EventArgs e)
        {
            label1.Text = button44.Text;
        }

        private void button45_Click(object sender, EventArgs e)
        {
            label1.Text = button45.Text;
        }

        private void button46_Click(object sender, EventArgs e)
        {
            label1.Text = button46.Text;
        }

        private void button47_Click(object sender, EventArgs e)
        {
            label1.Text = button47.Text;
        }

        private void button48_Click(object sender, EventArgs e)
        {
            label1.Text = button48.Text;
        }

        private void button49_Click(object sender, EventArgs e)
        {
            label1.Text = button49.Text;
        }

        private void button50_Click(object sender, EventArgs e)
        {
            label1.Text = button50.Text;
        }

        private void button51_Click(object sender, EventArgs e)
        {
            label1.Text = button51.Text;
        }

        private void button52_Click(object sender, EventArgs e)
        {
            label1.Text = button52.Text;
        }

        private void button53_Click(object sender, EventArgs e)
        {
            label1.Text = button53.Text;
        }

        private void button54_Click(object sender, EventArgs e)
        {
            label1.Text = button54.Text;
        }

        private void button55_Click(object sender, EventArgs e)
        {
            label1.Text = button55.Text;
        }

        private void button56_Click(object sender, EventArgs e)
        {
            label1.Text = button56.Text;
        }

        private void button57_Click(object sender, EventArgs e)
        {
            label1.Text = button57.Text;
        }

        private void button58_Click(object sender, EventArgs e)
        {
            label1.Text = button58.Text;
        }

        private void button59_Click(object sender, EventArgs e)
        {
            label1.Text = button59.Text;
        }

        private void button60_Click(object sender, EventArgs e)
        {
            label1.Text = button60.Text;
        }

        private void button61_Click(object sender, EventArgs e)
        {
            label1.Text = button61.Text;
        }

        private void button62_Click(object sender, EventArgs e)
        {
            label1.Text = button62.Text;
        }

        private void button63_Click(object sender, EventArgs e)
        {
            label1.Text = button63.Text;
        }

        private void button64_Click(object sender, EventArgs e)
        {
            label1.Text = button64.Text;
        }

        private void button65_Click(object sender, EventArgs e)
        {
            label1.Text = button65.Text;
        }

        private void button66_Click(object sender, EventArgs e)
        {
            label1.Text = button66.Text;
        }

        private void button67_Click(object sender, EventArgs e)
        {
            label1.Text = button67.Text;
        }

        private void button68_Click(object sender, EventArgs e)
        {
            label1.Text = button68.Text;
        }

        private void button69_Click(object sender, EventArgs e)
        {
            label1.Text = button69.Text;
        }

        private void button70_Click(object sender, EventArgs e)
        {
            label1.Text = button70.Text;
        }

        private void button71_Click(object sender, EventArgs e)
        {
            label1.Text = button71.Text;
        }

        private void button72_Click(object sender, EventArgs e)
        {
            label1.Text = button72.Text;
        }

        private void button73_Click(object sender, EventArgs e)
        {
            label1.Text = button73.Text;
        }

        private void button74_Click(object sender, EventArgs e)
        {
            label1.Text = button74.Text;
        }

        private void button75_Click(object sender, EventArgs e)
        {
            label1.Text = button75.Text;
        }

        private void button76_Click(object sender, EventArgs e)
        {
            label1.Text = button76.Text;
        }

        private void button77_Click(object sender, EventArgs e)
        {
            label1.Text = button77.Text;
        }

        private void button78_Click(object sender, EventArgs e)
        {
            label1.Text = button78.Text;
        }

        private void button79_Click(object sender, EventArgs e)
        {
            label1.Text = button79.Text;
        }

        private void button86_Click(object sender, EventArgs e)
        {
            label1.Text = button86.Text;
        }

        private void button87_Click(object sender, EventArgs e)
        {
            label1.Text = button87.Text;
        }

        private void button85_Click(object sender, EventArgs e)
        {
            label1.Text = button85.Text;
        }

        private void button84_Click(object sender, EventArgs e)
        {
            label1.Text = button84.Text;
        }

        private void button83_Click(object sender, EventArgs e)
        {
            label1.Text = button83.Text;
        }

        private void button82_Click(object sender, EventArgs e)
        {
            label1.Text = button82.Text;
        }

        private void button81_Click(object sender, EventArgs e)
        {
            label1.Text = button81.Text;
        }

        private void button80_Click(object sender, EventArgs e)
        {
            label1.Text = button80.Text;
        }

        private void button88_Click(object sender, EventArgs e)
        {
            label1.Text = button88.Text;
        }

        private void button89_Click(object sender, EventArgs e)
        {
            label1.Text = button89.Text;
        }

        private void button90_Click(object sender, EventArgs e)
        {
            label1.Text = button90.Text;
        }

        private void button91_Click(object sender, EventArgs e)
        {
            label1.Text = button91.Text;
        }

        private void button92_Click(object sender, EventArgs e)
        {
            label1.Text = button92.Text;
        }

        private void button101_Click(object sender, EventArgs e)
        {
            label1.Text = button101.Text;
        }

        private void button100_Click(object sender, EventArgs e)
        {
            label1.Text = button100.Text;
        }

        private void button99_Click(object sender, EventArgs e)
        {
            label1.Text = button99.Text;
        }

        private void button98_Click(object sender, EventArgs e)
        {
            label1.Text = button98.Text;
        }

        private void button97_Click(object sender, EventArgs e)
        {
            label1.Text = button97.Text;
        }

        private void button96_Click(object sender, EventArgs e)
        {
            label1.Text = button96.Text;
        }

        private void button95_Click(object sender, EventArgs e)
        {
            label1.Text = button95.Text;
        }

        private void button94_Click(object sender, EventArgs e)
        {
            label1.Text = button94.Text;
        }

        private void button93_Click(object sender, EventArgs e)
        {
            label1.Text = button93.Text;
        }

        private void button108_Click(object sender, EventArgs e)
        {
            label1.Text = button108.Text;
        }

        private void button107_Click(object sender, EventArgs e)
        {
            label1.Text = button107.Text;
        }

        private void button106_Click(object sender, EventArgs e)
        {
            label1.Text = button106.Text;
        }

        private void button105_Click(object sender, EventArgs e)
        {
            label1.Text = button105.Text;
        }

        private void button104_Click(object sender, EventArgs e)
        {
            label1.Text = button104.Text;
        }

        private void button103_Click(object sender, EventArgs e)
        {
            label1.Text = button103.Text;
        }

        private void button102_Click(object sender, EventArgs e)
        {
            label1.Text = button102.Text;
        }

        private void button114_Click(object sender, EventArgs e)
        {
            label1.Text = button114.Text;
        }

        private void button113_Click(object sender, EventArgs e)
        {
            label1.Text = button113.Text;
        }

        private void button112_Click(object sender, EventArgs e)
        {
            label1.Text = button112.Text;
        }

        private void button111_Click(object sender, EventArgs e)
        {
            label1.Text = button111.Text;
        }

        private void button110_Click(object sender, EventArgs e)
        {
            label1.Text = button110.Text;
        }

        private void button109_Click(object sender, EventArgs e)
        {
            label1.Text = button109.Text;
        }

        private void button115_Click(object sender, EventArgs e)
        {
            label1.Text = button115.Text;
        }

    }
}
