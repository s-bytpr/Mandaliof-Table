﻿namespace anasor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(47, 430);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 18);
            this.label1.TabIndex = 67;
            this.label1.TextChanged += new System.EventHandler(this.label1_TextChanged);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.BurlyWood;
            this.button16.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Location = new System.Drawing.Point(604, 44);
            this.button16.Margin = new System.Windows.Forms.Padding(2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(41, 35);
            this.button16.TabIndex = 84;
            this.button16.Text = "C";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.BurlyWood;
            this.button15.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(645, 79);
            this.button15.Margin = new System.Windows.Forms.Padding(2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(41, 35);
            this.button15.TabIndex = 83;
            this.button15.Text = "P";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.BurlyWood;
            this.button14.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(645, 44);
            this.button14.Margin = new System.Windows.Forms.Padding(2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(41, 35);
            this.button14.TabIndex = 82;
            this.button14.Text = "N";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.BurlyWood;
            this.button13.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(685, 114);
            this.button13.Margin = new System.Windows.Forms.Padding(2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(41, 35);
            this.button13.TabIndex = 81;
            this.button13.Text = "Se";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.BurlyWood;
            this.button12.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(685, 79);
            this.button12.Margin = new System.Windows.Forms.Padding(2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(41, 35);
            this.button12.TabIndex = 80;
            this.button12.Text = "S";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.BurlyWood;
            this.button11.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(685, 44);
            this.button11.Margin = new System.Windows.Forms.Padding(2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(41, 35);
            this.button11.TabIndex = 79;
            this.button11.Text = "O";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.BurlyWood;
            this.button10.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(725, 114);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(41, 35);
            this.button10.TabIndex = 78;
            this.button10.Text = "Br";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.BurlyWood;
            this.button9.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(725, 79);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(41, 35);
            this.button9.TabIndex = 77;
            this.button9.Text = "Cl";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.BurlyWood;
            this.button8.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(725, 44);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(41, 35);
            this.button8.TabIndex = 76;
            this.button8.Text = "F";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.BurlyWood;
            this.button7.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(725, 149);
            this.button7.Margin = new System.Windows.Forms.Padding(2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(41, 35);
            this.button7.TabIndex = 75;
            this.button7.Text = "I";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.BurlyWood;
            this.button6.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(765, 184);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(41, 35);
            this.button6.TabIndex = 74;
            this.button6.Text = "Rn";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.BurlyWood;
            this.button5.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(765, 149);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(41, 35);
            this.button5.TabIndex = 73;
            this.button5.Text = "Xe";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.BurlyWood;
            this.button4.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(765, 114);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(41, 35);
            this.button4.TabIndex = 72;
            this.button4.Text = "Kr";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.BurlyWood;
            this.button3.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(765, 79);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(41, 35);
            this.button3.TabIndex = 71;
            this.button3.Text = "Ar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.BurlyWood;
            this.button2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(765, 44);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(41, 35);
            this.button2.TabIndex = 70;
            this.button2.Text = "Ne";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.DarkKhaki;
            this.button17.Location = new System.Drawing.Point(11, 8);
            this.button17.Margin = new System.Windows.Forms.Padding(2);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(50, 22);
            this.button17.TabIndex = 69;
            this.button17.Text = "خروج";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.BurlyWood;
            this.button1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(765, 8);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(41, 35);
            this.button1.TabIndex = 68;
            this.button1.Text = "He";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.LightGreen;
            this.button18.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(562, 44);
            this.button18.Margin = new System.Windows.Forms.Padding(2);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(41, 35);
            this.button18.TabIndex = 85;
            this.button18.Text = "B";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.LightGreen;
            this.button19.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(604, 79);
            this.button19.Margin = new System.Windows.Forms.Padding(2);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(41, 35);
            this.button19.TabIndex = 86;
            this.button19.Text = "Si";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.LightGreen;
            this.button20.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(645, 114);
            this.button20.Margin = new System.Windows.Forms.Padding(2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(41, 35);
            this.button20.TabIndex = 87;
            this.button20.Text = "As";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.LightGreen;
            this.button21.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(685, 149);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(41, 35);
            this.button21.TabIndex = 88;
            this.button21.Text = "Te";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.LightGreen;
            this.button22.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(725, 184);
            this.button22.Margin = new System.Windows.Forms.Padding(2);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(41, 35);
            this.button22.TabIndex = 89;
            this.button22.Text = "At";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.LightGreen;
            this.button23.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(604, 114);
            this.button23.Margin = new System.Windows.Forms.Padding(2);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(41, 35);
            this.button23.TabIndex = 90;
            this.button23.Text = "Ge";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.LightGreen;
            this.button24.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(645, 149);
            this.button24.Margin = new System.Windows.Forms.Padding(2);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(41, 35);
            this.button24.TabIndex = 91;
            this.button24.Text = "Sb";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Aquamarine;
            this.button25.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(562, 79);
            this.button25.Margin = new System.Windows.Forms.Padding(2);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(41, 35);
            this.button25.TabIndex = 92;
            this.button25.Text = "Al";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Aquamarine;
            this.button26.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(562, 114);
            this.button26.Margin = new System.Windows.Forms.Padding(2);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(41, 35);
            this.button26.TabIndex = 93;
            this.button26.Text = "Ga";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Aquamarine;
            this.button27.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(562, 149);
            this.button27.Margin = new System.Windows.Forms.Padding(2);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(41, 35);
            this.button27.TabIndex = 94;
            this.button27.Text = "In";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Aquamarine;
            this.button28.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(604, 149);
            this.button28.Margin = new System.Windows.Forms.Padding(2);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(41, 35);
            this.button28.TabIndex = 95;
            this.button28.Text = "Sn";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Aquamarine;
            this.button29.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Location = new System.Drawing.Point(604, 184);
            this.button29.Margin = new System.Windows.Forms.Padding(2);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(41, 35);
            this.button29.TabIndex = 96;
            this.button29.Text = "Pb";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Aquamarine;
            this.button30.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(685, 184);
            this.button30.Margin = new System.Windows.Forms.Padding(2);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(41, 35);
            this.button30.TabIndex = 97;
            this.button30.Text = "Po";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Aquamarine;
            this.button31.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.Location = new System.Drawing.Point(645, 184);
            this.button31.Margin = new System.Windows.Forms.Padding(2);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(41, 35);
            this.button31.TabIndex = 98;
            this.button31.Text = "Bi";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Aquamarine;
            this.button32.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.Location = new System.Drawing.Point(562, 184);
            this.button32.Margin = new System.Windows.Forms.Padding(2);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(41, 35);
            this.button32.TabIndex = 99;
            this.button32.Text = "Tl";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Aquamarine;
            this.button33.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Location = new System.Drawing.Point(604, 218);
            this.button33.Margin = new System.Windows.Forms.Padding(2);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(41, 35);
            this.button33.TabIndex = 100;
            this.button33.Text = "Uuq";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Aquamarine;
            this.button34.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.Location = new System.Drawing.Point(685, 218);
            this.button34.Margin = new System.Windows.Forms.Padding(2);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(41, 35);
            this.button34.TabIndex = 101;
            this.button34.Text = "Uuh";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Aquamarine;
            this.button35.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.Location = new System.Drawing.Point(521, 114);
            this.button35.Margin = new System.Windows.Forms.Padding(2);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(41, 35);
            this.button35.TabIndex = 102;
            this.button35.Text = "Zn";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Aquamarine;
            this.button36.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.Location = new System.Drawing.Point(521, 149);
            this.button36.Margin = new System.Windows.Forms.Padding(2);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(41, 35);
            this.button36.TabIndex = 103;
            this.button36.Text = "Cd";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.Aquamarine;
            this.button37.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button37.Location = new System.Drawing.Point(521, 184);
            this.button37.Margin = new System.Windows.Forms.Padding(2);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(41, 35);
            this.button37.TabIndex = 104;
            this.button37.Text = "Hg";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.Aquamarine;
            this.button38.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.Location = new System.Drawing.Point(521, 218);
            this.button38.Margin = new System.Windows.Forms.Padding(2);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(41, 35);
            this.button38.TabIndex = 105;
            this.button38.Text = "Uub";
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.Aquamarine;
            this.button39.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.Location = new System.Drawing.Point(481, 114);
            this.button39.Margin = new System.Windows.Forms.Padding(2);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(41, 35);
            this.button39.TabIndex = 106;
            this.button39.Text = "Cu";
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Aquamarine;
            this.button40.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.Location = new System.Drawing.Point(481, 149);
            this.button40.Margin = new System.Windows.Forms.Padding(2);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(41, 35);
            this.button40.TabIndex = 107;
            this.button40.Text = "Ag";
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.Aquamarine;
            this.button41.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button41.Location = new System.Drawing.Point(481, 184);
            this.button41.Margin = new System.Windows.Forms.Padding(2);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(41, 35);
            this.button41.TabIndex = 108;
            this.button41.Text = "Au";
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.Aquamarine;
            this.button42.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button42.Location = new System.Drawing.Point(481, 218);
            this.button42.Margin = new System.Windows.Forms.Padding(2);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(41, 35);
            this.button42.TabIndex = 109;
            this.button42.Text = "Uuu";
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.Aquamarine;
            this.button43.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button43.Location = new System.Drawing.Point(441, 114);
            this.button43.Margin = new System.Windows.Forms.Padding(2);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(41, 35);
            this.button43.TabIndex = 110;
            this.button43.Text = "Ni";
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.Aquamarine;
            this.button44.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button44.Location = new System.Drawing.Point(441, 149);
            this.button44.Margin = new System.Windows.Forms.Padding(2);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(41, 35);
            this.button44.TabIndex = 111;
            this.button44.Text = "Pd";
            this.button44.UseVisualStyleBackColor = false;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.Aquamarine;
            this.button45.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button45.Location = new System.Drawing.Point(441, 184);
            this.button45.Margin = new System.Windows.Forms.Padding(2);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(41, 35);
            this.button45.TabIndex = 112;
            this.button45.Text = "Pt";
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Aquamarine;
            this.button46.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button46.Location = new System.Drawing.Point(441, 218);
            this.button46.Margin = new System.Windows.Forms.Padding(2);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(41, 35);
            this.button46.TabIndex = 113;
            this.button46.Text = "Uun";
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.Aquamarine;
            this.button47.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button47.Location = new System.Drawing.Point(401, 114);
            this.button47.Margin = new System.Windows.Forms.Padding(2);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(41, 35);
            this.button47.TabIndex = 114;
            this.button47.Text = "Co";
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Aquamarine;
            this.button48.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button48.Location = new System.Drawing.Point(401, 149);
            this.button48.Margin = new System.Windows.Forms.Padding(2);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(41, 35);
            this.button48.TabIndex = 115;
            this.button48.Text = "Rh";
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Aquamarine;
            this.button49.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button49.Location = new System.Drawing.Point(401, 184);
            this.button49.Margin = new System.Windows.Forms.Padding(2);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(41, 35);
            this.button49.TabIndex = 116;
            this.button49.Text = "Ir";
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.Aquamarine;
            this.button50.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button50.Location = new System.Drawing.Point(401, 217);
            this.button50.Margin = new System.Windows.Forms.Padding(2);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(41, 35);
            this.button50.TabIndex = 117;
            this.button50.Text = "Mt";
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.Aquamarine;
            this.button51.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button51.Location = new System.Drawing.Point(361, 114);
            this.button51.Margin = new System.Windows.Forms.Padding(2);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(41, 35);
            this.button51.TabIndex = 118;
            this.button51.Text = "Fe";
            this.button51.UseVisualStyleBackColor = false;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.Aquamarine;
            this.button52.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button52.Location = new System.Drawing.Point(361, 149);
            this.button52.Margin = new System.Windows.Forms.Padding(2);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(41, 35);
            this.button52.TabIndex = 119;
            this.button52.Text = "Ru";
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.Aquamarine;
            this.button53.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button53.Location = new System.Drawing.Point(361, 184);
            this.button53.Margin = new System.Windows.Forms.Padding(2);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(41, 35);
            this.button53.TabIndex = 120;
            this.button53.Text = "Os";
            this.button53.UseVisualStyleBackColor = false;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.Aquamarine;
            this.button54.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button54.Location = new System.Drawing.Point(361, 218);
            this.button54.Margin = new System.Windows.Forms.Padding(2);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(41, 35);
            this.button54.TabIndex = 121;
            this.button54.Text = "Hs";
            this.button54.UseVisualStyleBackColor = false;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.Aquamarine;
            this.button55.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button55.Location = new System.Drawing.Point(321, 114);
            this.button55.Margin = new System.Windows.Forms.Padding(2);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(41, 35);
            this.button55.TabIndex = 122;
            this.button55.Text = "Mn";
            this.button55.UseVisualStyleBackColor = false;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.Aquamarine;
            this.button56.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button56.Location = new System.Drawing.Point(321, 149);
            this.button56.Margin = new System.Windows.Forms.Padding(2);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(41, 35);
            this.button56.TabIndex = 123;
            this.button56.Text = "Tc";
            this.button56.UseVisualStyleBackColor = false;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.Aquamarine;
            this.button57.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button57.Location = new System.Drawing.Point(321, 184);
            this.button57.Margin = new System.Windows.Forms.Padding(2);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(41, 35);
            this.button57.TabIndex = 124;
            this.button57.Text = "Re";
            this.button57.UseVisualStyleBackColor = false;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.Aquamarine;
            this.button58.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button58.Location = new System.Drawing.Point(321, 217);
            this.button58.Margin = new System.Windows.Forms.Padding(2);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(41, 35);
            this.button58.TabIndex = 125;
            this.button58.Text = "Bh";
            this.button58.UseVisualStyleBackColor = false;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.Aquamarine;
            this.button59.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button59.Location = new System.Drawing.Point(281, 114);
            this.button59.Margin = new System.Windows.Forms.Padding(2);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(41, 35);
            this.button59.TabIndex = 126;
            this.button59.Text = "Cr";
            this.button59.UseVisualStyleBackColor = false;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.Aquamarine;
            this.button60.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button60.Location = new System.Drawing.Point(281, 149);
            this.button60.Margin = new System.Windows.Forms.Padding(2);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(41, 35);
            this.button60.TabIndex = 127;
            this.button60.Text = "Mo";
            this.button60.UseVisualStyleBackColor = false;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.Aquamarine;
            this.button61.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button61.Location = new System.Drawing.Point(281, 184);
            this.button61.Margin = new System.Windows.Forms.Padding(2);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(41, 35);
            this.button61.TabIndex = 128;
            this.button61.Text = "W";
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.Aquamarine;
            this.button62.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button62.Location = new System.Drawing.Point(281, 217);
            this.button62.Margin = new System.Windows.Forms.Padding(2);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(41, 35);
            this.button62.TabIndex = 129;
            this.button62.Text = "Sg";
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.Aquamarine;
            this.button63.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button63.Location = new System.Drawing.Point(241, 114);
            this.button63.Margin = new System.Windows.Forms.Padding(2);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(41, 35);
            this.button63.TabIndex = 130;
            this.button63.Text = "V";
            this.button63.UseVisualStyleBackColor = false;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.Aquamarine;
            this.button64.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button64.Location = new System.Drawing.Point(241, 149);
            this.button64.Margin = new System.Windows.Forms.Padding(2);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(41, 35);
            this.button64.TabIndex = 131;
            this.button64.Text = "Nb";
            this.button64.UseVisualStyleBackColor = false;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.Aquamarine;
            this.button65.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button65.Location = new System.Drawing.Point(241, 184);
            this.button65.Margin = new System.Windows.Forms.Padding(2);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(41, 35);
            this.button65.TabIndex = 132;
            this.button65.Text = "Ta";
            this.button65.UseVisualStyleBackColor = false;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.Aquamarine;
            this.button66.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button66.Location = new System.Drawing.Point(241, 217);
            this.button66.Margin = new System.Windows.Forms.Padding(2);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(41, 35);
            this.button66.TabIndex = 133;
            this.button66.Text = "Db";
            this.button66.UseVisualStyleBackColor = false;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.Aquamarine;
            this.button67.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button67.Location = new System.Drawing.Point(79, 8);
            this.button67.Margin = new System.Windows.Forms.Padding(2);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(41, 35);
            this.button67.TabIndex = 134;
            this.button67.Text = "H";
            this.button67.UseVisualStyleBackColor = false;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.Aquamarine;
            this.button68.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button68.Location = new System.Drawing.Point(201, 114);
            this.button68.Margin = new System.Windows.Forms.Padding(2);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(41, 35);
            this.button68.TabIndex = 135;
            this.button68.Text = "Ti";
            this.button68.UseVisualStyleBackColor = false;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.Color.Aquamarine;
            this.button69.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button69.Location = new System.Drawing.Point(201, 149);
            this.button69.Margin = new System.Windows.Forms.Padding(2);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(41, 35);
            this.button69.TabIndex = 136;
            this.button69.Text = "Zr";
            this.button69.UseVisualStyleBackColor = false;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.Aquamarine;
            this.button70.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button70.Location = new System.Drawing.Point(201, 184);
            this.button70.Margin = new System.Windows.Forms.Padding(2);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(41, 35);
            this.button70.TabIndex = 137;
            this.button70.Text = "Hf";
            this.button70.UseVisualStyleBackColor = false;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.Aquamarine;
            this.button71.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button71.Location = new System.Drawing.Point(201, 217);
            this.button71.Margin = new System.Windows.Forms.Padding(2);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(41, 35);
            this.button71.TabIndex = 138;
            this.button71.Text = "Rf";
            this.button71.UseVisualStyleBackColor = false;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.Aquamarine;
            this.button72.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button72.Location = new System.Drawing.Point(161, 114);
            this.button72.Margin = new System.Windows.Forms.Padding(2);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(41, 35);
            this.button72.TabIndex = 139;
            this.button72.Text = "Sc";
            this.button72.UseVisualStyleBackColor = false;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.Aquamarine;
            this.button73.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button73.Location = new System.Drawing.Point(161, 149);
            this.button73.Margin = new System.Windows.Forms.Padding(2);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(41, 35);
            this.button73.TabIndex = 140;
            this.button73.Text = "Y";
            this.button73.UseVisualStyleBackColor = false;
            this.button73.Click += new System.EventHandler(this.button73_Click);
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.Color.Aquamarine;
            this.button74.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button74.Location = new System.Drawing.Point(161, 184);
            this.button74.Margin = new System.Windows.Forms.Padding(2);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(41, 25);
            this.button74.TabIndex = 141;
            this.button74.Text = "La";
            this.button74.UseVisualStyleBackColor = false;
            this.button74.Click += new System.EventHandler(this.button74_Click);
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.Color.Aquamarine;
            this.button75.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button75.Location = new System.Drawing.Point(161, 227);
            this.button75.Margin = new System.Windows.Forms.Padding(2);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(41, 25);
            this.button75.TabIndex = 142;
            this.button75.Text = "Ac";
            this.button75.UseVisualStyleBackColor = false;
            this.button75.Click += new System.EventHandler(this.button75_Click);
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.Aquamarine;
            this.button76.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button76.Location = new System.Drawing.Point(121, 114);
            this.button76.Margin = new System.Windows.Forms.Padding(2);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(41, 35);
            this.button76.TabIndex = 143;
            this.button76.Text = "Ca";
            this.button76.UseVisualStyleBackColor = false;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.Aquamarine;
            this.button77.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button77.Location = new System.Drawing.Point(121, 149);
            this.button77.Margin = new System.Windows.Forms.Padding(2);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(41, 35);
            this.button77.TabIndex = 144;
            this.button77.Text = "Sr";
            this.button77.UseVisualStyleBackColor = false;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.Color.Aquamarine;
            this.button78.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button78.Location = new System.Drawing.Point(121, 184);
            this.button78.Margin = new System.Windows.Forms.Padding(2);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(41, 35);
            this.button78.TabIndex = 145;
            this.button78.Text = "Ba";
            this.button78.UseVisualStyleBackColor = false;
            this.button78.Click += new System.EventHandler(this.button78_Click);
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.Aquamarine;
            this.button79.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button79.Location = new System.Drawing.Point(121, 217);
            this.button79.Margin = new System.Windows.Forms.Padding(2);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(41, 35);
            this.button79.TabIndex = 146;
            this.button79.Text = "Ra";
            this.button79.UseVisualStyleBackColor = false;
            this.button79.Click += new System.EventHandler(this.button79_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(167, 210);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 18);
            this.label2.TabIndex = 147;
            this.label2.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(167, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 18);
            this.label3.TabIndex = 148;
            this.label3.Text = "**";
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.Aquamarine;
            this.button80.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button80.Location = new System.Drawing.Point(79, 217);
            this.button80.Margin = new System.Windows.Forms.Padding(2);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(41, 35);
            this.button80.TabIndex = 149;
            this.button80.Text = "Fr";
            this.button80.UseVisualStyleBackColor = false;
            this.button80.Click += new System.EventHandler(this.button80_Click);
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.Color.Aquamarine;
            this.button81.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button81.Location = new System.Drawing.Point(79, 184);
            this.button81.Margin = new System.Windows.Forms.Padding(2);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(41, 35);
            this.button81.TabIndex = 150;
            this.button81.Text = "Cs";
            this.button81.UseVisualStyleBackColor = false;
            this.button81.Click += new System.EventHandler(this.button81_Click);
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.Color.Aquamarine;
            this.button82.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button82.Location = new System.Drawing.Point(79, 149);
            this.button82.Margin = new System.Windows.Forms.Padding(2);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(41, 35);
            this.button82.TabIndex = 151;
            this.button82.Text = "Rb";
            this.button82.UseVisualStyleBackColor = false;
            this.button82.Click += new System.EventHandler(this.button82_Click);
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.Color.Aquamarine;
            this.button83.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button83.Location = new System.Drawing.Point(79, 114);
            this.button83.Margin = new System.Windows.Forms.Padding(2);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(41, 35);
            this.button83.TabIndex = 152;
            this.button83.Text = "k";
            this.button83.UseVisualStyleBackColor = false;
            this.button83.Click += new System.EventHandler(this.button83_Click);
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.Color.Aquamarine;
            this.button84.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button84.Location = new System.Drawing.Point(121, 79);
            this.button84.Margin = new System.Windows.Forms.Padding(2);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(41, 35);
            this.button84.TabIndex = 153;
            this.button84.Text = "Mg";
            this.button84.UseVisualStyleBackColor = false;
            this.button84.Click += new System.EventHandler(this.button84_Click);
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.Color.Aquamarine;
            this.button85.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button85.Location = new System.Drawing.Point(79, 79);
            this.button85.Margin = new System.Windows.Forms.Padding(2);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(41, 35);
            this.button85.TabIndex = 154;
            this.button85.Text = "Na";
            this.button85.UseVisualStyleBackColor = false;
            this.button85.Click += new System.EventHandler(this.button85_Click);
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.Color.Aquamarine;
            this.button86.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button86.Location = new System.Drawing.Point(79, 44);
            this.button86.Margin = new System.Windows.Forms.Padding(2);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(41, 35);
            this.button86.TabIndex = 155;
            this.button86.Text = "Li";
            this.button86.UseVisualStyleBackColor = false;
            this.button86.Click += new System.EventHandler(this.button86_Click);
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.Color.Aquamarine;
            this.button87.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button87.Location = new System.Drawing.Point(121, 44);
            this.button87.Margin = new System.Windows.Forms.Padding(2);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(41, 35);
            this.button87.TabIndex = 156;
            this.button87.Text = "Be";
            this.button87.UseVisualStyleBackColor = false;
            this.button87.Click += new System.EventHandler(this.button87_Click);
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.Aquamarine;
            this.button88.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button88.Location = new System.Drawing.Point(241, 315);
            this.button88.Margin = new System.Windows.Forms.Padding(2);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(41, 35);
            this.button88.TabIndex = 157;
            this.button88.Text = "Ce";
            this.button88.UseVisualStyleBackColor = false;
            this.button88.Click += new System.EventHandler(this.button88_Click);
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.Color.Aquamarine;
            this.button89.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button89.Location = new System.Drawing.Point(281, 315);
            this.button89.Margin = new System.Windows.Forms.Padding(2);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(41, 35);
            this.button89.TabIndex = 158;
            this.button89.Text = "Pr";
            this.button89.UseVisualStyleBackColor = false;
            this.button89.Click += new System.EventHandler(this.button89_Click);
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.Color.Aquamarine;
            this.button90.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button90.Location = new System.Drawing.Point(321, 315);
            this.button90.Margin = new System.Windows.Forms.Padding(2);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(41, 35);
            this.button90.TabIndex = 159;
            this.button90.Text = "Nd";
            this.button90.UseVisualStyleBackColor = false;
            this.button90.Click += new System.EventHandler(this.button90_Click);
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.Color.Aquamarine;
            this.button91.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button91.Location = new System.Drawing.Point(361, 315);
            this.button91.Margin = new System.Windows.Forms.Padding(2);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(41, 35);
            this.button91.TabIndex = 160;
            this.button91.Text = "Pm";
            this.button91.UseVisualStyleBackColor = false;
            this.button91.Click += new System.EventHandler(this.button91_Click);
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.Color.Aquamarine;
            this.button92.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button92.Location = new System.Drawing.Point(401, 315);
            this.button92.Margin = new System.Windows.Forms.Padding(2);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(41, 35);
            this.button92.TabIndex = 161;
            this.button92.Text = "Sm";
            this.button92.UseVisualStyleBackColor = false;
            this.button92.Click += new System.EventHandler(this.button92_Click);
            // 
            // button93
            // 
            this.button93.BackColor = System.Drawing.Color.Aquamarine;
            this.button93.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button93.Location = new System.Drawing.Point(765, 315);
            this.button93.Margin = new System.Windows.Forms.Padding(2);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(41, 35);
            this.button93.TabIndex = 162;
            this.button93.Text = "Lu";
            this.button93.UseVisualStyleBackColor = false;
            this.button93.Click += new System.EventHandler(this.button93_Click);
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.Color.Aquamarine;
            this.button94.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button94.Location = new System.Drawing.Point(725, 315);
            this.button94.Margin = new System.Windows.Forms.Padding(2);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(41, 35);
            this.button94.TabIndex = 163;
            this.button94.Text = "Yb";
            this.button94.UseVisualStyleBackColor = false;
            this.button94.Click += new System.EventHandler(this.button94_Click);
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.Color.Aquamarine;
            this.button95.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button95.Location = new System.Drawing.Point(685, 315);
            this.button95.Margin = new System.Windows.Forms.Padding(2);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(41, 35);
            this.button95.TabIndex = 164;
            this.button95.Text = "Tm";
            this.button95.UseVisualStyleBackColor = false;
            this.button95.Click += new System.EventHandler(this.button95_Click);
            // 
            // button96
            // 
            this.button96.BackColor = System.Drawing.Color.Aquamarine;
            this.button96.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button96.Location = new System.Drawing.Point(645, 315);
            this.button96.Margin = new System.Windows.Forms.Padding(2);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(41, 35);
            this.button96.TabIndex = 165;
            this.button96.Text = "Er";
            this.button96.UseVisualStyleBackColor = false;
            this.button96.Click += new System.EventHandler(this.button96_Click);
            // 
            // button97
            // 
            this.button97.BackColor = System.Drawing.Color.Aquamarine;
            this.button97.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button97.Location = new System.Drawing.Point(604, 315);
            this.button97.Margin = new System.Windows.Forms.Padding(2);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(41, 35);
            this.button97.TabIndex = 166;
            this.button97.Text = "Ho";
            this.button97.UseVisualStyleBackColor = false;
            this.button97.Click += new System.EventHandler(this.button97_Click);
            // 
            // button98
            // 
            this.button98.BackColor = System.Drawing.Color.Aquamarine;
            this.button98.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button98.Location = new System.Drawing.Point(562, 315);
            this.button98.Margin = new System.Windows.Forms.Padding(2);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(41, 35);
            this.button98.TabIndex = 167;
            this.button98.Text = "Dy";
            this.button98.UseVisualStyleBackColor = false;
            this.button98.Click += new System.EventHandler(this.button98_Click);
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.Color.Aquamarine;
            this.button99.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button99.Location = new System.Drawing.Point(521, 315);
            this.button99.Margin = new System.Windows.Forms.Padding(2);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(41, 35);
            this.button99.TabIndex = 168;
            this.button99.Text = "Tb";
            this.button99.UseVisualStyleBackColor = false;
            this.button99.Click += new System.EventHandler(this.button99_Click);
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.Color.Aquamarine;
            this.button100.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button100.Location = new System.Drawing.Point(481, 315);
            this.button100.Margin = new System.Windows.Forms.Padding(2);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(41, 35);
            this.button100.TabIndex = 169;
            this.button100.Text = "Gd";
            this.button100.UseVisualStyleBackColor = false;
            this.button100.Click += new System.EventHandler(this.button100_Click);
            // 
            // button101
            // 
            this.button101.BackColor = System.Drawing.Color.Aquamarine;
            this.button101.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button101.Location = new System.Drawing.Point(441, 315);
            this.button101.Margin = new System.Windows.Forms.Padding(2);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(41, 35);
            this.button101.TabIndex = 170;
            this.button101.Text = "Eu";
            this.button101.UseVisualStyleBackColor = false;
            this.button101.Click += new System.EventHandler(this.button101_Click);
            // 
            // button102
            // 
            this.button102.BackColor = System.Drawing.Color.Aquamarine;
            this.button102.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button102.Location = new System.Drawing.Point(481, 354);
            this.button102.Margin = new System.Windows.Forms.Padding(2);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(41, 35);
            this.button102.TabIndex = 171;
            this.button102.Text = "Cm";
            this.button102.UseVisualStyleBackColor = false;
            this.button102.Click += new System.EventHandler(this.button102_Click);
            // 
            // button103
            // 
            this.button103.BackColor = System.Drawing.Color.Aquamarine;
            this.button103.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button103.Location = new System.Drawing.Point(441, 354);
            this.button103.Margin = new System.Windows.Forms.Padding(2);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(41, 35);
            this.button103.TabIndex = 172;
            this.button103.Text = "Am";
            this.button103.UseVisualStyleBackColor = false;
            this.button103.Click += new System.EventHandler(this.button103_Click);
            // 
            // button104
            // 
            this.button104.BackColor = System.Drawing.Color.Aquamarine;
            this.button104.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button104.Location = new System.Drawing.Point(401, 354);
            this.button104.Margin = new System.Windows.Forms.Padding(2);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(41, 35);
            this.button104.TabIndex = 173;
            this.button104.Text = "Pu";
            this.button104.UseVisualStyleBackColor = false;
            this.button104.Click += new System.EventHandler(this.button104_Click);
            // 
            // button105
            // 
            this.button105.BackColor = System.Drawing.Color.Aquamarine;
            this.button105.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button105.Location = new System.Drawing.Point(361, 354);
            this.button105.Margin = new System.Windows.Forms.Padding(2);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(41, 35);
            this.button105.TabIndex = 174;
            this.button105.Text = "Np";
            this.button105.UseVisualStyleBackColor = false;
            this.button105.Click += new System.EventHandler(this.button105_Click);
            // 
            // button106
            // 
            this.button106.BackColor = System.Drawing.Color.Aquamarine;
            this.button106.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button106.Location = new System.Drawing.Point(321, 354);
            this.button106.Margin = new System.Windows.Forms.Padding(2);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(41, 35);
            this.button106.TabIndex = 175;
            this.button106.Text = "U";
            this.button106.UseVisualStyleBackColor = false;
            this.button106.Click += new System.EventHandler(this.button106_Click);
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.Color.Aquamarine;
            this.button107.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button107.Location = new System.Drawing.Point(281, 354);
            this.button107.Margin = new System.Windows.Forms.Padding(2);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(41, 35);
            this.button107.TabIndex = 176;
            this.button107.Text = "Pa";
            this.button107.UseVisualStyleBackColor = false;
            this.button107.Click += new System.EventHandler(this.button107_Click);
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.Color.Aquamarine;
            this.button108.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button108.Location = new System.Drawing.Point(241, 354);
            this.button108.Margin = new System.Windows.Forms.Padding(2);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(41, 35);
            this.button108.TabIndex = 177;
            this.button108.Text = "Th";
            this.button108.UseVisualStyleBackColor = false;
            this.button108.Click += new System.EventHandler(this.button108_Click);
            // 
            // button109
            // 
            this.button109.BackColor = System.Drawing.Color.Aquamarine;
            this.button109.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button109.Location = new System.Drawing.Point(725, 354);
            this.button109.Margin = new System.Windows.Forms.Padding(2);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(41, 35);
            this.button109.TabIndex = 178;
            this.button109.Text = "No";
            this.button109.UseVisualStyleBackColor = false;
            this.button109.Click += new System.EventHandler(this.button109_Click);
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.Color.Aquamarine;
            this.button110.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button110.Location = new System.Drawing.Point(685, 354);
            this.button110.Margin = new System.Windows.Forms.Padding(2);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(41, 35);
            this.button110.TabIndex = 179;
            this.button110.Text = "Md";
            this.button110.UseVisualStyleBackColor = false;
            this.button110.Click += new System.EventHandler(this.button110_Click);
            // 
            // button111
            // 
            this.button111.BackColor = System.Drawing.Color.Aquamarine;
            this.button111.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button111.Location = new System.Drawing.Point(645, 354);
            this.button111.Margin = new System.Windows.Forms.Padding(2);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(41, 35);
            this.button111.TabIndex = 180;
            this.button111.Text = "Fm";
            this.button111.UseVisualStyleBackColor = false;
            this.button111.Click += new System.EventHandler(this.button111_Click);
            // 
            // button112
            // 
            this.button112.BackColor = System.Drawing.Color.Aquamarine;
            this.button112.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button112.Location = new System.Drawing.Point(604, 354);
            this.button112.Margin = new System.Windows.Forms.Padding(2);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(41, 35);
            this.button112.TabIndex = 181;
            this.button112.Text = "Es";
            this.button112.UseVisualStyleBackColor = false;
            this.button112.Click += new System.EventHandler(this.button112_Click);
            // 
            // button113
            // 
            this.button113.BackColor = System.Drawing.Color.Aquamarine;
            this.button113.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button113.Location = new System.Drawing.Point(562, 354);
            this.button113.Margin = new System.Windows.Forms.Padding(2);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(41, 35);
            this.button113.TabIndex = 182;
            this.button113.Text = "Cf";
            this.button113.UseVisualStyleBackColor = false;
            this.button113.Click += new System.EventHandler(this.button113_Click);
            // 
            // button114
            // 
            this.button114.BackColor = System.Drawing.Color.Aquamarine;
            this.button114.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button114.Location = new System.Drawing.Point(521, 354);
            this.button114.Margin = new System.Windows.Forms.Padding(2);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(41, 35);
            this.button114.TabIndex = 183;
            this.button114.Text = "Bk";
            this.button114.UseVisualStyleBackColor = false;
            this.button114.Click += new System.EventHandler(this.button114_Click);
            // 
            // button115
            // 
            this.button115.BackColor = System.Drawing.Color.Aquamarine;
            this.button115.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button115.Location = new System.Drawing.Point(765, 354);
            this.button115.Margin = new System.Windows.Forms.Padding(2);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(41, 35);
            this.button115.TabIndex = 184;
            this.button115.Text = "Lr";
            this.button115.UseVisualStyleBackColor = false;
            this.button115.Click += new System.EventHandler(this.button115_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(149, 323);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 18);
            this.label4.TabIndex = 185;
            this.label4.Text = "Lanthanides*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(157, 362);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 18);
            this.label5.TabIndex = 186;
            this.label5.Text = "Actinides**";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(50, 451);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(750, 154);
            this.pictureBox1.TabIndex = 187;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(722, 629);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 13);
            this.label6.TabIndex = 188;
            this.label6.Text = "طراح: سمیه بیات پور";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(826, 651);
            this.ControlBox = false;
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button115);
            this.Controls.Add(this.button114);
            this.Controls.Add(this.button113);
            this.Controls.Add(this.button112);
            this.Controls.Add(this.button111);
            this.Controls.Add(this.button110);
            this.Controls.Add(this.button109);
            this.Controls.Add(this.button108);
            this.Controls.Add(this.button107);
            this.Controls.Add(this.button106);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button104);
            this.Controls.Add(this.button103);
            this.Controls.Add(this.button102);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button99);
            this.Controls.Add(this.button98);
            this.Controls.Add(this.button97);
            this.Controls.Add(this.button96);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;


    }
}

